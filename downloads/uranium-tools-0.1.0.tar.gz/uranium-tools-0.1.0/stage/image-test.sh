#!/bin/bash
# boot the image
set -u
B=${B:-$HOME/Downloads/stirner-build}
IMG=${1:-$B/uranium.img}
W=$(mktemp -d -p "$B/tmp")
OV=/usr/share/edk2/x64/OVMF_CODE.4m.fd
cp /usr/share/edk2/x64/OVMF_VARS.4m.fd "$W/vars.fd"
cp --reflink=auto "$IMG" "$W/disk.img"

PRE='echo
export PATH=/rod/bin:/rod/profile/bin:/rod/init/bin
t() { n=$1; shift; if "$@" > /dev/null 2>&1; then echo "T PASS $n"; else echo "T FAIL $n"; fi; }
'
script() { printf '#uranium-test\n%s\n%s\n' "$PRE" "$1" > "$W/test.txt"; truncate -s 1M "$W/test.txt"; }

fail=0
run() { # name timeout extra-qemu-args
    name=$1; to=$2; shift 2
    qemu-system-x86_64 -enable-kvm -m 2048 -smp 4 -machine q35 \
        -drive if=pflash,format=raw,readonly=on,file=$OV -drive if=pflash,format=raw,file="$W/vars.fd" \
        -drive file="$W/disk.img",if=virtio,format=raw -drive file="$W/test.txt",if=virtio,format=raw,readonly=on \
        -nic user,model=virtio-net-pci -display none -serial stdio -monitor none -no-reboot "$@" < /dev/null > "$W/$name.log" 2>&1 &
    q=$!; s=0
    while kill -0 $q 2> /dev/null; do
        sleep 5; s=$((s + 5))
        if grep -a -q -E 'dropping to a shell|Kernel panic' "$W/$name.log"; then echo "$name: boot failed"; fail=1; break; fi
        if [ $s -ge "$to" ]; then echo "$name: timeout"; fail=1; break; fi
    done
    kill $q 2> /dev/null; wait $q 2> /dev/null
    tr -d '\r' < "$W/$name.log" | grep -a -o -E 'T (PASS|FAIL) [^[]*' | sed "s/^/$name: /"
    grep -a -q '^T FAIL' "$W/$name.log" && fail=1
    return 0
}

script 'i=0; while [ $i -lt 60 ]; do ip addr 2> /dev/null | grep -q "inet 10\.0\.2" && break; sleep 1; i=$((i + 1)); done
t "os-release names the system" grep -q "UraniumOS" /etc/os-release
t "the kernel is the one we built" sh -c "uname -r | grep -q uranium"
t "boot partition mounted" mountpoint -q /boot
t "home mounted" mountpoint -q /home
t "top level visible" test -d /run/scram/top/.scram
t "network up" sh -c "ip addr | grep -q \"inet 10.0.2\""
t "services supervised" sh -c "[ \$(sv status /etc/service/* | grep -c \"^run\") -ge 4 ]"
t "boot menu has the install frame" grep -q "Frame " /boot/limine.conf
t "blastdoor loaded" sh -c "nft list ruleset | grep -q policy.drop"
t "ntpd supervised" sh -c "sv status /etc/service/ntpd | grep -q ^run"
t "crond supervised" sh -c "sv status /etc/service/crond | grep -q ^run"
t "service log written" sh -c "sleep 3; test -d /var/log/dhcp && ls /var/log/dhcp | grep -q current"
t "geiger passes" geiger
t "trial service supervised" sh -c "sv status /etc/service/trial | grep -q ^run"
t "geiger fails when a service is down" sh -c "sv d /etc/service/ntpd; sleep 2; ! geiger; sv u /etc/service/ntpd; sleep 3; geiger"
t "scram status explains the frames" sh -c "scram status | grep -q prune:"
t "a frame keeps its own kernel" sh -c "scram frame kern > /dev/null && ls /run/scram/top/.scram/*-kern/boot/vmlinuz /run/scram/top/.scram/*-kern/boot/id"
t "the menu has frame entries with a kernel" sh -c "scram boot > /dev/null && grep -A2 \"^/Frame\" /boot/limine.conf | grep -q vmlinuz"
t "zram swap active" sh -c "grep -q zram /proc/swaps"
t "man page found" sh -c "man rod | grep -qi generation"
t "completion installed" test -f /rod/share/bash-completion/completions/rod
t "doctor passes" scram doctor
t "setup creates a user" sh -c "echo pw | setup --hostname boxy --user ann --password-stdin --timezone Europe/Helsinki --keymap us && grep -q boxy /etc/hostname && id ann | grep -q wheel"
t "doas elevates a wheel user" sh -c "echo permit nopass ann >> /etc/doas.conf && setpriv --reuid=$(id -u ann) --regid=$(id -g ann) --init-groups /rod/wrappers/doas id -u | grep -qx 0"
t "ssh server starts with setup" sh -c "setup --ssh && sleep 6 && sv status /etc/service/sshd | grep -q ^run"
t "ssh key login works" sh -c "mkdir -p /home/ann/.ssh && ssh-keygen -q -t ed25519 -N \"\" -f /tmp/k && cp /tmp/k.pub /home/ann/.ssh/authorized_keys && chown -R ann /home/ann/.ssh && chmod 700 /home/ann/.ssh && ssh -i /tmp/k -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ann@127.0.0.1 id -un | grep -qx ann"
t "scratch prompt differs" sh -c "SCRAM_SCRATCH=1 bash -lic \"echo \\\$PS1\" 2> /dev/null | grep -q scratch"
t "console login is busybox login" sh -c "test -x /rod/init/bin/login && grep -q bin/login /etc/sv/getty-tty1/run"
t "clear is installed" command -v clear
t "fetch shows the system" sh -c "fetch --no-color --frames 1 | grep -q Uranium"
mkdir -p /etc/sv/sbtest
printf "nonet\nrw /var/lib/sbtest\n" > /etc/sv/sbtest/sandbox
cat > /etc/sv/sbtest/run <<RUNEOF
#!/bin/sh
export PATH=/rod/bin:/rod/profile/bin
exec hazmat -s sh -c "if test -e /etc/hostname; then echo visible; else echo hidden; fi > /var/lib/sbtest/out; exec sleep 600"
RUNEOF
chmod +x /etc/sv/sbtest/run; ln -s /etc/sv/sbtest /etc/service/sbtest; sleep 9
t "a sandboxed service runs" sh -c "sv status /etc/service/sbtest | grep -q ^run"
t "a sandboxed service cannot see the system" sh -c "grep -qx hidden /var/lib/sbtest/out"
sv d /etc/service/sbtest; rm -f /etc/service/sbtest
t "extra kernel args in the menu" sh -c "echo testarg=1 > /etc/cmdline && scram boot && grep -q testarg=1 /boot/limine.conf"
t "rod sync" rod +s
t "rod dry run changes nothing" sh -c "rod -n +i jq | grep -q installing && ! command -v jq && ! grep -qx jq /rod/installed"
t "rod install over the network" sh -c "rod +i hello && hello | grep -q Hello"
t "rod +l explicit lists what was asked for" sh -c "rod +l explicit | grep -qx hello"
t "rod +n describes a package" sh -c "rod +n hello | grep -qi hello"
t "rod +h previews an update" rod +h
t "rod +w names the package" sh -c "rod +w /rod/profile/bin/hello | grep -q hello"
t "sysctl defaults applied" sh -c "grep -qx 2 /proc/sys/kernel/kptr_restrict && grep -qx 2 /proc/sys/fs/protected_regular"
t "home is nosuid and nodev" sh -c "grep /home /proc/mounts | grep nosuid | grep -q nodev"
t "boot is noexec" sh -c "grep /boot /proc/mounts | grep -q noexec"
t "tmp is nosuid" sh -c "grep -E ^tmp /proc/mounts | grep -q nosuid"
t "kernel is hardened" sh -c "grep -q CONFIG_RANDOMIZE_BASE=y /rod/profile/boot/config && grep -q CONFIG_STRICT_KERNEL_RWX=y /rod/profile/boot/config && grep -q CONFIG_HARDENED_USERCOPY=y /rod/profile/boot/config && grep -q CONFIG_SECURITY_LANDLOCK=y /rod/profile/boot/config"
t "kcore is absent" sh -c "! test -e /proc/kcore"
t "yama is active" sh -c "grep -qx 2 /proc/sys/kernel/yama/ptrace_scope"
t "kernel arguments hardened" sh -c "grep -q slab_nomerge /proc/cmdline"
t "signing key installed" test -f /etc/signify/uranium-0.1.pub
t "signify is installed" sh -c "command -v signify"
t "hazmat shows a listed path" sh -c "hazmat -r /etc/hostname coreutils -- cat /etc/hostname | grep -q ."
t "hazmat hides the rest" sh -c "hazmat -r /etc/hostname coreutils -- test ! -e /etc/passwd"
t "hazmat runs a package" sh -c "hazmat hello -- hello | grep -q Hello"
t "container runs a package" sh -c "silo box hello -- hello | grep -q Hello"
t "container has its own hostname" sh -c "silo box -- cat /etc/hostname | grep -qx box"
t "container cannot see the host" sh -c "silo box -- test ! -e /rod/nixpkgs"
t "container is listed" sh -c "silo | grep -qx box"
t "container is removed" sh -c "silo -d box && ! silo | grep -qx box"
t "a frame brings a deleted container back" sh -c "silo keep > /dev/null 2>&1; silo keep hello -- true && scram frame -m kept ckeep > /dev/null && silo -d keep && ! silo | grep -qx keep && scram restore /rod/containers/keep ckeep > /dev/null && silo | grep -qx keep && silo keep -- hello | grep -q Hello"
t "builds are refused, packages are binaries" sh -c "! nix-build --no-out-link -E \"derivation { name = \\\"x\\\"; system = builtins.currentSystem; builder = \\\"/bin/sh\\\"; args = [\\\"-c\\\" \\\"echo hi > \\\$out\\\"]; }\""
t "rod +e opens an environment" sh -c "rod +e hello -- hello | grep -q Hello"
t "rod +d opens a build environment" sh -c "rod +d hello -- hello | grep -q Hello"
t "rod +y shows dependencies" sh -c "rod +y hello | grep -q glibc"
t "update in a copy" scram try "echo tried > /etc/tried"
t "commit scheduled for boot" scram commit --boot
sync; echo "T REBOOT"; reboot'
run boot1 1500

script 'sleep 5
t "committed update applied at boot" test -f /etc/tried
t "pre-commit frame exists" sh -c "scram roll | grep -q pre-commit"
t "the update is on trial" sh -c "scram status | grep -q trial:"
t "package still installed" sh -c "hello | grep -q Hello"
t "flash scheduled for boot" scram flash --boot install
sync; echo "T REBOOT"; reboot'
run boot2 400

script 'sleep 5
t "an unconfirmed update was reverted" sh -c "scram roll | grep -q pre-revert"
t "flash applied at boot" sh -c "! test -e /etc/tried"
t "pre-flash frame exists" sh -c "scram roll | grep -q pre-flash"
t "package gone after flash" sh -c "! command -v hello"
echo "T DONE"; poweroff'
run boot3 400

ID=$(ls "$B/img/.scram" | grep -- '-install$' | head -n 1)
script 'sleep 5
t "frame boot: committed file absent" sh -c "! test -e /etc/tried"
t "frame boot: root is a copy of the frame" sh -c "grep -q \"subvol=/.scram/live/@\" /proc/mounts"
echo "T DONE"; poweroff'
run frame 300 -kernel "$B/bootprof/boot/vmlinuz" -initrd "$B/bootprof/boot/initrd" -append "root=LABEL=uranium rw console=ttyS0 uranium.test uranium.frame=$ID"

echo "RESULT fail=$fail"
echo "logs: $W"
exit $fail
