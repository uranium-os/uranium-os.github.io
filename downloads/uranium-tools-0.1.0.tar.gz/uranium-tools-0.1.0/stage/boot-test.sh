#!/bin/sh
# boot the stage
set -eu

B=${B:-$HOME/Downloads/stirner-build}
R=$B/root
I=$B/img
KERNEL=${KERNEL:-/usr/lib/modules/$(uname -r)/vmlinuz}

[ -d "$I" ] && chmod -R u+w "${I:?}" && rm -rf "${I:?}"
mkdir -p "$I"
cp -a --reflink=always "$R" "$I/@"
mkdir -p "$I/@home/root"
rm -f "$I/@/etc/rc.new"
cp "$I/@/etc/rc" "$I/@/etc/rc.new"
echo '[ -x /rod/test.sh ] && /rod/test.sh' >> "$I/@/etc/rc.new"
mv "$I/@/etc/rc.new" "$I/@/etc/rc"
chmod 755 "$I/@/etc/rc"
cat > "$I/@/rod/test.sh" <<'CONF'
#!/rod/profile/bin/sh
export PATH=/rod/bin:/rod/profile/bin:/rod/init/bin
echo "BOOT-OK $(uname -sr)"
head -1 /etc/os-release
echo "root: $(ls / | tr '\n' ' ')"
echo "packages: $(rod +l | wc -l)"
nix --version
echo "shell: $(readlink /bin/sh)"
echo TEST-DONE
echo o > /proc/sysrq-trigger
CONF
chmod 755 "$I/@/rod/test.sh"
rm -f "$B/disk.img"
truncate -s 8G "$B/disk.img"
unshare --map-auto --map-root-user mkfs.btrfs -q -f --rootdir "$I" --subvol rw:@ --subvol rw:@home "$B/disk.img"
timeout 300 qemu-system-x86_64 -enable-kvm -m 2048 -kernel "$KERNEL" \
    -drive file="$B/disk.img",if=virtio,format=raw \
    -append "console=ttyS0 root=/dev/vda rootfstype=btrfs rootflags=subvol=@ rw init=/rod/init/bin/init panic=-1" \
    -nic user,model=virtio-net-pci -display none -serial stdio -monitor none -no-reboot | tee "$B/boot.log"
grep -q TEST-DONE "$B/boot.log"
