#!/bin/sh
# build live iso
set -eu

B=${B:-$HOME/Downloads/stirner-build}
HERE=$(cd "$(dirname "$0")/.." && pwd)
IR=$B/img-root
TR=$B/tool-root
BP=$B/bootprof
LIVE=$B/live-root
ISO=$B/iso
VER=${VER:-0.1.0}
OUT=${OUT:-$HOME/Downloads}

run_in() {
    d=$1; shift
    unshare --map-auto --map-root-user --mount sh -c '
        mount --rbind /dev "$1/dev"; mount --rbind /proc "$1/proc"
        r=$1; shift
        exec chroot "$r" /usr/bin/env -i HOME=/root TERM=xterm PATH=/rod/bin:/rod/profile/bin NIX_CONFIG="max-jobs = auto" "$@"' sh "$d" "$@"
}

echo "== live root"
[ -d "$LIVE" ] && chmod -R u+w "${LIVE:?}" && rm -rf "${LIVE:?}"
cp -a --reflink=always "$IR" "$LIVE"
cp "$HERE/uranium-install" "$HERE/uranium-chroot" "$HERE/genfstab" "$LIVE/rod/bin/"
chmod 755 "$LIVE/rod/bin/uranium-install" "$LIVE/rod/bin/uranium-chroot" "$LIVE/rod/bin/genfstab"
: > "$LIVE/etc/fstab"
echo uranium-live > "$LIVE/etc/hostname"
: > "$LIVE/etc/live"

echo "== squashfs"
if [ ! -x "$TR/rod/profile/bin/mksquashfs" ] && ! ls "$TR"/nix/store/*squashfs-tools*/bin/mksquashfs > /dev/null 2>&1; then
    cp "$B/nixexprs.tar.xz" "$TR/tmp/"
    run_in "$TR" rod +s file:///tmp/nixexprs.tar.xz
    run_in "$TR" rod +i squashfsTools xorriso
fi
rm -rf "${ISO:?}"; mkdir -p "$ISO/live" "$TR/src" "$TR/out"
unshare --map-auto --map-root-user --mount sh -c '
    mount --rbind /dev "$1/dev"; mount --bind "$2" "$1/src"; mount --bind "$3" "$1/out"
    r=$1; shift; shift; shift
    exec chroot "$r" /usr/bin/env -i PATH=/rod/profile/bin sh -c "mksquashfs /src /out/root.squashfs -comp xz -noappend -no-progress > /dev/null"' sh "$TR" "$LIVE" "$ISO/live"

echo "== efi image"
ESP=$B/esp-iso
[ -d "$ESP" ] && rm -rf "${ESP:?}"
mkdir -p "$ESP/EFI/BOOT" "$ISO/uranium"
cp "$BP/share/limine/BOOTX64.EFI" "$ESP/EFI/BOOT/"
cp "$BP/boot/vmlinuz" "$BP/boot/initrd" "$ISO/uranium/"
cat > "$ISO/limine.conf" <<'CONF'
timeout: 5
serial: yes

/UraniumOS live
    protocol: linux
    path: boot():/uranium/vmlinuz
    module_path: boot():/uranium/initrd
    cmdline: uranium.live console=tty0 console=ttyS0,115200 slab_nomerge vsyscall=none debugfs=off randomize_kstack_offset=on

/UraniumOS live, shell in the initramfs
    protocol: linux
    path: boot():/uranium/vmlinuz
    module_path: boot():/uranium/initrd
    cmdline: uranium.live uranium.shell console=tty0 console=ttyS0,115200 slab_nomerge vsyscall=none debugfs=off randomize_kstack_offset=on
CONF
rm -f "$TR/esp.img"; mkdir -p "$TR/esp"
unshare --map-auto --map-root-user --mount sh -c '
    mount --rbind /dev "$1/dev"; mount --bind "$2" "$1/esp"
    r=$1; shift; shift
    exec chroot "$r" /usr/bin/env -i PATH=/rod/profile/bin sh -c "
        mkfs.vfat -F32 -n URANIUMEFI -C /esp.img 34000 > /dev/null &&
        mcopy -s -i /esp.img /esp/* ::"' sh "$TR" "$ESP"
mv "$TR/esp.img" "$ISO/efi.img"

echo "== iso"
OUTISO=$OUT/uranium-$VER.iso
rm -f "$OUTISO"
xorriso -as mkisofs -iso-level 3 -full-iso9660-filenames -volid URANIUM -joliet -R -r \
    --efi-boot efi.img -efi-boot-part --efi-boot-image --protective-msdos-label \
    -o "$OUTISO" "$ISO" 2>&1 | tail -n 3
ls -la "$OUTISO"
