#!/bin/sh
# build disk image
set -eu

B=${B:-$HOME/Downloads/stirner-build}
HERE=$(cd "$(dirname "$0")/.." && pwd)
R=$B/root
IR=$B/img-root
TR=$B/tool-root
I=$B/img
VER=${VER:-0.1.0}
OUT=${OUT:-$HOME/Downloads}
ESPMB=256
ROOTMB=${ROOTMB:-8192}

# run in copy
run_in() {
    d=$1; shift
    unshare --map-auto --map-root-user --mount sh -c '
        mount --rbind /dev "$1/dev"; mount --rbind /proc "$1/proc"
        r=$1; shift
        exec chroot "$r" /usr/bin/env -i HOME=/root TERM=xterm PATH=/rod/bin:/rod/profile/bin NIX_CONFIG="max-jobs = auto" "$@"' sh "$d" "$@"
}
fresh() { [ -d "$1" ] && chmod -R u+w "${1:?}" && rm -rf "${1:?}"; cp -a --reflink=always "$R" "$1"; cp "$B/nixexprs.tar.xz" "$1/tmp/"; }

echo "== kernel, initrd"
if [ -z "${KEEPIMG:-}" ] || [ ! -d "$IR" ]; then
    fresh "$IR"
    run_in "$IR" rod +s file:///tmp/nixexprs.tar.xz
    run_in "$IR" rod +i linux-uranium initramfs-uranium
fi
echo "== refresh"
rm -f "$IR/rod/bin/firewall" "$IR/rod/bin/blastdoor" "$IR/rod/bin/geiger" "$IR/rod/bin/silo" "$IR/rod/bin/hazmat"
cp "$HERE/rod" "$HERE/scram" "$HERE/uranium-install" "$HERE/uranium-chroot" "$HERE/uranium-man" "$HERE/uranium-tip" "$HERE/uranium-session" "$HERE/uranium-desktop" "$HERE/genfstab" "$IR/rod/bin/"
chmod 755 "$IR"/rod/bin/*
cp "$HERE"/man/*.1 "$IR/rod/share/man/man1/"
cp -a "$HERE"/recipes/. "$IR/rod/recipes/"
cp -a "$HERE/stage/skel/." "$IR/"
# new init script
if [ -n "${KEEPIMG:-}" ]; then
    cp "$B/nixexprs.tar.xz" "$IR/tmp/"
    run_in "$IR" rod +s file:///tmp/nixexprs.tar.xz
    run_in "$IR" rod +r linux-uranium initramfs-uranium
fi
# rust tools
cp "$B/nixexprs.tar.xz" "$IR/tmp/"
run_in "$IR" rod +s file:///tmp/nixexprs.tar.xz
rm -rf "${IR:?}/homeless-shelter"
run_in "$IR" rod +i uranium-tools
run_in "$IR" rod +r uranium-tools
rm -rf "${IR:?}/homeless-shelter"
if ! run_in "$IR" sh -c 'command -v fetch' > /dev/null 2>&1; then
    cp "$B/nixexprs.tar.xz" "$IR/tmp/"
    run_in "$IR" rod +s file:///tmp/nixexprs.tar.xz
    run_in "$IR" rod +i fetch -r fastfetch
fi
if ! run_in "$IR" sh -c 'command -v signify' > /dev/null 2>&1; then
    cp "$B/nixexprs.tar.xz" "$IR/tmp/"
    run_in "$IR" rod +s file:///tmp/nixexprs.tar.xz
    run_in "$IR" rod +i signify
fi
run_in "$IR" rod +l

echo "== boot files"
ID=$(date +%Y%m%d-%H%M%S)-install
BP=$B/bootprof
[ -d "$BP" ] && chmod -R u+w "$BP" && rm -rf "$BP"
mkdir -p "$BP/boot" "$BP/share/limine"
run_in "$IR" sh -c 'cp -L /rod/profile/boot/vmlinuz /tmp/vmlinuz; cp -L /rod/profile/boot/initrd /tmp/initrd; cp -L /rod/profile/share/limine/BOOTX64.EFI /tmp/BOOTX64.EFI'
mv "$IR/tmp/vmlinuz" "$IR/tmp/initrd" "$BP/boot/"; mv "$IR/tmp/BOOTX64.EFI" "$BP/share/limine/"
rm -rf "${IR:?}/rod/nixpkgs" "${IR:?}/tmp/nixexprs.tar.xz"
run_in "$IR" nix-collect-garbage -d > /dev/null

echo "== etc"
cat > "$IR/etc/fstab" <<'CONF'
LABEL=uranium      /      btrfs  noatime,subvol=@       0 0
LABEL=uranium      /home  btrfs  noatime,nodev,nosuid,subvol=@home   0 0
LABEL=URANIUMESP   /boot  vfat   umask=0077,nodev,nosuid,noexec             0 2
CONF
mkdir -p "$IR/boot" "$IR/home"

echo "== btrfs tree"
[ -d "$I" ] && chmod -R u+w "${I:?}" && rm -rf "${I:?}"
mkdir -p "$I/.scram/$ID" "$I/@home"
cp -a --reflink=always "$IR" "$I/@"
mkdir -p "$I/@/var/cache" "$I/@/var/tmp" "$I/@/rod/nixpkgs"
cp -a --reflink=always "$I/@" "$I/.scram/$ID/@"
mkdir "$I/.scram/$ID/@home"
printf '@ rod/nixpkgs\n@ var/cache\n@ var/tmp\n' > "$I/.scram/keep.list"

echo "== boot menu"
ESP=$B/esp
[ -d "$ESP" ] && rm -rf "${ESP:?}"
mkdir -p "$ESP"
SCRAM_FLASH=$I/.scram SCRAM_BOOT=$ESP SCRAM_PROFILE=$BP SCRAM_CMDLINE=$HERE/stage/skel/etc/cmdline sh "$HERE/scram" boot

echo "== tools for the esp"
if [ ! -d "$TR" ]; then fresh "$TR"; run_in "$TR" rod +s file:///tmp/nixexprs.tar.xz; run_in "$TR" rod +i mtools dosfstools; fi
rm -f "$B/esp.img"
mkdir -p "$TR/esp"
mount_esp() { :; }
unshare --map-auto --map-root-user --mount sh -c '
    mount --rbind /dev "$1/dev"; mount --bind "$2" "$1/esp"
    r=$1; shift; shift
    exec chroot "$r" /usr/bin/env -i PATH=/rod/profile/bin sh -c "
        mkfs.vfat -F32 -n URANIUMESP -C /esp.img '$((ESPMB * 1024))' > /dev/null &&
        mcopy -s -i /esp.img /esp/* ::"' sh "$TR" "$ESP"
mv "$TR/esp.img" "$B/esp.img"

echo "== root image"
rm -f "$B/root.img"
truncate -s "${ROOTMB}M" "$B/root.img"
unshare --map-auto --map-root-user mkfs.btrfs -q -f -L uranium --rootdir "$I" --reflink \
    --subvol rw:@ --subvol rw:@home --subvol rw:@/var/cache --subvol rw:@/var/tmp --subvol rw:@/rod/nixpkgs \
    --subvol "ro:.scram/$ID/@" --subvol "ro:.scram/$ID/@home" "$B/root.img"

# mkfs may grow it
ROOTMB=$((($(stat -c %s "$B/root.img") + 1048575) / 1048576))

echo "== disk"
IMG=$B/uranium.img
rm -f "$IMG"
truncate -s "$((1 + ESPMB + ROOTMB + 1))M" "$IMG"
sfdisk -q "$IMG" <<CONF
label: gpt
first-lba: 2048
start=1MiB, size=${ESPMB}MiB, type=C12A7328-F81F-11D2-BA4B-00A0C93EC93B, name="ESP"
type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, name="uranium-root"
CONF
dd if="$B/esp.img" of="$IMG" bs=1M seek=1 conv=notrunc,sparse status=none
dd if="$B/root.img" of="$IMG" bs=1M seek=$((1 + ESPMB)) conv=notrunc,sparse status=none
ls -la "$IMG"
