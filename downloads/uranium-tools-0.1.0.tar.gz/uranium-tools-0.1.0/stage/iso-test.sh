#!/bin/bash
# iso install test
set -u
B=${B:-$HOME/Downloads/stirner-build}
ISO=${1:-$HOME/Downloads/uranium-0.1.0.iso}
OV=/usr/share/edk2/x64/OVMF_CODE.4m.fd
mkdir -p "$B/tmp"
W=$(mktemp -d -p "$B/tmp")
cp /usr/share/edk2/x64/OVMF_VARS.4m.fd "$W/vars.fd"
truncate -s 8G "$W/target.img"

PRE='echo
export PATH=/rod/bin:/rod/profile/bin:/rod/init/bin
t() { n=$1; shift; if "$@" > /dev/null 2>&1; then echo "T PASS $n"; else echo "T FAIL $n"; fi; }
'
script() { printf '#uranium-test\n%s\n%s\n' "$PRE" "$1" > "$W/test.txt"; truncate -s 1M "$W/test.txt"; }

fail=0
run() { # name timeout extra-qemu-args
    name=$1; to=$2; shift 2
    qemu-system-x86_64 -enable-kvm -m 3072 -smp 4 -machine q35 \
        -drive if=pflash,format=raw,readonly=on,file=$OV -drive if=pflash,format=raw,file="$W/vars.fd" \
        -drive file="$W/target.img",if=virtio,format=raw -drive file="$W/test.txt",if=virtio,format=raw,readonly=on \
        -nic user,model=virtio-net-pci -display none -serial stdio -monitor none -no-reboot "$@" < /dev/null > "$W/$name.log" 2>&1 &
    q=$!; s=0
    while kill -0 $q 2> /dev/null; do
        sleep 5; s=$((s + 5))
        if grep -a -q -E 'dropping to a shell|Kernel panic' "$W/$name.log"; then echo "$name: boot failed"; fail=1; break; fi
        if [ $s -ge "$to" ]; then echo "$name: timeout"; fail=1; break; fi
    done
    kill $q 2> /dev/null; wait $q 2> /dev/null
    tr -d '\r' < "$W/$name.log" | grep -a -o -E 'T (PASS|FAIL) [^[]*' | sed "s/^/$name: /"
    grep -a -q '^T FAIL' "$W/$name.log" && fail=1
    return 0
}

script 'cat > /tmp/cfg <<CFG
DISK=/dev/vda
HOST=testbox
USERNAME=ann
USERPASS=userpw
ROOTPASS=rootpw
ZONE=Europe/Helsinki
KEYMAP=us
PROFILE=server
CFG
t "live system is running" test -e /etc/live
t "live root is an overlay" sh -c "grep -q overlay /proc/mounts"
t "installer is on the path" command -v uranium-install
t "installer finishes" sh -c "uranium-install --config /tmp/cfg -y > /tmp/install.log 2>&1 || { tail -n 20 /tmp/install.log; false; }"
echo "T DONE"; poweroff'
run live 900 -drive file="$ISO",media=cdrom,if=ide,readonly=on -boot d

script 'sleep 5
t "hostname was set" sh -c "[ \$(cat /etc/hostname) = testbox ]"
t "the user exists in wheel" sh -c "id ann | grep -q wheel"
t "time zone was set" sh -c "readlink /etc/localtime | grep -q Helsinki"
t "root is the btrfs subvolume" sh -c "grep -q \"subvol=/@\" /proc/mounts"
t "home is a subvolume" sh -c "grep -q \"subvol=/@home\" /proc/mounts"
t "boot partition mounted" mountpoint -q /boot
t "the first frame exists" sh -c "scram roll | grep -q install"
t "boot menu has the frame" sh -c "grep -q Frame /boot/limine.conf"
t "scram doctor passes" scram doctor
t "ssh server is enabled" test -L /etc/service/sshd
t "not a live system" sh -c "! test -e /etc/live"
t "network is up" sh -c "i=0; while [ \$i -lt 40 ]; do ip addr | grep -q \"inet 10.0.2\" && break; sleep 1; i=\$((i+1)); done; ip addr | grep -q \"inet 10.0.2\""
t "set expansion works" sh -c "mkdir -p /tmp/s && echo hello > /tmp/s/tiny && ROD_SETS=/tmp/s rod +s > /dev/null 2>&1 && ROD_SETS=/tmp/s rod +i @tiny && hello | grep -q Hello"
echo "T DONE"; poweroff'
run installed 600

echo "RESULT fail=$fail"
echo "logs: $W"
