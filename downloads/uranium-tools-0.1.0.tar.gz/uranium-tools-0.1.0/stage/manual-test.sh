#!/bin/bash
# manual install test
set -u
B=${B:-$HOME/Downloads/stirner-build}
OUT=${OUT:-$HOME/Downloads}
ISO=${1:-$OUT/uranium-0.1.0.iso}
OV=/usr/share/edk2/x64/OVMF_CODE.4m.fd
mkdir -p "$B/tmp"
W=$(mktemp -d -p "$B/tmp")
cp /usr/share/edk2/x64/OVMF_VARS.4m.fd "$W/vars.fd"
truncate -s 8G "$W/target.img"

# stage over http
mkdir -p "$W/www/downloads"
cp "$OUT"/uranium-stage-0.1.0.tar.xz "$OUT"/uranium-stage-0.1.0.tar.xz.sha256 "$W/www/downloads/"
(cd "$W/www" && exec python3 -m http.server 8765 --bind 127.0.0.1 > "$W/http.log" 2>&1) &
H=$!
trap 'kill $H 2> /dev/null' EXIT

PRE='echo
export PATH=/rod/bin:/rod/profile/bin:/rod/init/bin
t() { n=$1; shift; if "$@" > /dev/null 2>&1; then echo "T PASS $n"; else echo "T FAIL $n"; fi; }
'
script() { printf '#uranium-test\n%s\n%s\n' "$PRE" "$1" > "$W/test.txt"; truncate -s 1M "$W/test.txt"; }

fail=0
run() {
    name=$1; to=$2; shift 2
    qemu-system-x86_64 -enable-kvm -m 3072 -smp 4 -machine q35 \
        -drive if=pflash,format=raw,readonly=on,file=$OV -drive if=pflash,format=raw,file="$W/vars.fd" \
        -drive file="$W/target.img",if=virtio,format=raw -drive file="$W/test.txt",if=virtio,format=raw,readonly=on \
        -nic user,model=virtio-net-pci -display none -serial stdio -monitor none -no-reboot "$@" < /dev/null > "$W/$name.log" 2>&1 &
    q=$!; s=0
    while kill -0 $q 2> /dev/null; do
        sleep 5; s=$((s + 5))
        if grep -a -q -E 'dropping to a shell|Kernel panic' "$W/$name.log"; then echo "$name: boot failed"; fail=1; break; fi
        if [ $s -ge "$to" ]; then echo "$name: timeout"; fail=1; break; fi
    done
    kill $q 2> /dev/null; wait $q 2> /dev/null
    tr -d '\r' < "$W/$name.log" | grep -a -o -E 'T (PASS|FAIL) [^[]*' | sed "s/^/$name: /"
    grep -a -q '^T FAIL' "$W/$name.log" && fail=1
    return 0
}

script "$(cat "$(dirname "$0")/manual-steps.sh")"
run live 1500 -drive file="$ISO",media=cdrom,if=ide,readonly=on -boot d

script 'sleep 5
t "hostname" sh -c "[ \$(cat /etc/hostname) = manual ]"
t "user in wheel" sh -c "id ann | grep -q wheel"
t "time zone" sh -c "readlink /etc/localtime | grep -q Helsinki"
t "root subvolume" sh -c "grep -q \"subvol=/@\" /proc/mounts"
t "boot mounted" mountpoint -q /boot
t "frame exists" sh -c "scram roll | grep -q install"
t "doctor passes" scram doctor
t "not live" sh -c "! test -e /etc/live"
echo "T DONE"; poweroff'
run installed 600

echo "RESULT fail=$fail"
echo "logs: $W"
