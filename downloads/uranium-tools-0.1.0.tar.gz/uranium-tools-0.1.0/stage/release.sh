#!/bin/sh
# build every download
set -eu

B=${B:-$HOME/Downloads/stirner-build}
HERE=$(cd "$(dirname "$0")/.." && pwd)
OUT=${OUT:-$HOME/Downloads}
SITE=${SITE:-$HOME/Downloads/stirner-site}
VER=${VER:-0.1.0}

echo "== stage"
KEEP=1 QUICK="${QUICK:-}" sh "$HERE/stage/build-stage.sh"

echo "== image"
KEEPIMG=1 sh "$HERE/stage/build-image.sh"

echo "== stage tarball"
tar --owner=0 --group=0 --numeric-owner -C "$B/img-root" -cf - . | xz -T0 -6 > "$OUT/uranium-stage-$VER.tar.xz"
(cd "$OUT" && sha256sum "uranium-stage-$VER.tar.xz" > "uranium-stage-$VER.tar.xz.sha256")

echo "== iso"
sh "$HERE/stage/build-iso.sh"

echo "== tools"
rm -f "$OUT/uranium-tools-$VER.tar.gz"
tar czf "$OUT/uranium-tools-$VER.tar.gz" --transform "s,^trueflash,uranium-tools-$VER," -C "$(dirname "$HERE")" "$(basename "$HERE")"

echo "== sign"
K=${KEY:-$HOME/.local/share/uranium-signing/uranium-0.1.sec}
IR=$B/img-root
(cd "$OUT" && sha256sum "uranium-$VER.iso" "uranium-stage-$VER.tar.xz" "uranium-tools-$VER.tar.gz" > "$IR/tmp/SHA256")
cp "$K" "$IR/tmp/key.sec"
unshare --map-auto --map-root-user --mount sh -c '
    mount --rbind /dev "$1/dev"; mount --rbind /proc "$1/proc"
    exec chroot "$1" /usr/bin/env -i PATH=/rod/profile/bin signify -S -s /tmp/key.sec -m /tmp/SHA256 -x /tmp/SHA256.sig' sh "$IR"
rm -f "$IR/tmp/key.sec"
cp "$IR/tmp/SHA256" "$IR/tmp/SHA256.sig" "$OUT/"
rm -f "$IR/tmp/SHA256" "$IR/tmp/SHA256.sig"

echo "== site"
mkdir -p "$SITE/downloads"
for f in "uranium-$VER.iso" "uranium-stage-$VER.tar.xz" "uranium-tools-$VER.tar.gz"; do
    cp "$OUT/$f" "$SITE/downloads/$f"
    (cd "$SITE/downloads" && sha256sum "$f" > "$f.sha256")
    (cd "$OUT" && sha256sum "$f" > "$f.sha256")
done
cp "$OUT/SHA256" "$OUT/SHA256.sig" "$SITE/downloads/"
cp "$HERE/stage/skel/etc/signify/uranium-0.1.pub" "$SITE/downloads/"
ls -la "$SITE/downloads"
