#!/bin/sh
# build stage tarball
set -eu

B=${B:-$HOME/Downloads/stirner-build}
NP=${NIXPKGS:-$B/nixpkgs}
HERE=$(cd "$(dirname "$0")/.." && pwd)
R=$B/root
VER=${VER:-0.1.0}
OUT=${OUT:-$HOME/Downloads}
BASE="bashInteractive coreutils findutils gnugrep gnused gawk gnutar gzip xz bzip2 diffutils which less util-linux procps iproute2 glibc curl cacert btrfs-progs rsync nix runit limine bubblewrap cryptsetup nftables openssh mandoc kbd dosfstools iputils zstd file bash-completion ncurses fetch signify uranium-tools"

# run inside the stage
inroot() {
    unshare --map-auto --map-root-user --mount sh -c '
        mount --rbind /dev "$1/dev"
        mount --rbind /proc "$1/proc"
        r=$1; shift
        exec chroot "$r" "$ENVB" -i HOME=/root TERM=xterm PATH="$BP:/rod/bin" NIX_SSL_CERT_FILE="$CERT" "$@"' sh "$R" "$@"
}

if [ -z "${KEEP:-}" ] && [ -d "$R" ]; then chmod -R u+w "${R:?}" && rm -rf "${R:?}"; fi
mkdir -p "$R"

if [ -z "${QUICK:-}" ]; then
echo "== bootstrap closure"
BP=
for a in nix bashInteractive coreutils cacert curl gnutar xz gnugrep gnused findutils gzip; do
    for p in $(nix-build --no-out-link --store "local?root=$R" --option sandbox false "$NP" -A "$a"); do
        [ -d "$R$p/bin" ] && BP="$BP:$p/bin"
    done
done
BP=${BP#:}
export BP
BASH=$(for d in $(echo "$BP" | tr : ' '); do [ -x "$R$d/bash" ] && echo "$d/bash" && break; done)
ENVB=$(for d in $(echo "$BP" | tr : ' '); do [ -x "$R$d/env" ] && echo "$d/env" && break; done)
export ENVB
CERT=$(ls -d "$R"/nix/store/*-nss-cacert-*/etc/ssl/certs/ca-bundle.crt | head -1)
CERT=${CERT#"$R"}
export CERT

echo "== skeleton"
cd "$R"
for l in bin usr/bin sbin usr/sbin lib lib64/ld-linux-x86-64.so.2 etc/ssl/certs/ca-bundle.crt; do [ -L "$l" ] && rm "$l"; done
mkdir -p rod/recipes bin usr dev proc sys run tmp root home mnt boot var/log var/tmp var/cache etc/nix etc/scram.d rod/bin rod/share/man/man1 lib64
chmod 1777 tmp var/tmp
ln -sf "$BASH" bin/sh
rm -f rod/bin/firewall rod/bin/blastdoor rod/bin/geiger rod/bin/silo rod/bin/hazmat; cp "$HERE/rod" "$HERE/scram" "$HERE/uranium-install" "$HERE/uranium-chroot" "$HERE/uranium-man" "$HERE/uranium-tip" "$HERE/uranium-session" "$HERE/uranium-desktop" "$HERE/genfstab" rod/bin/
cp "$HERE"/man/*.1 rod/share/man/man1/
cp -a "$HERE"/recipes/. rod/recipes/
chmod 755 rod/bin/*
cat > etc/nix/nix.conf <<'CONF'
build-users-group =
sandbox = false
experimental-features = nix-command
substituters = https://cache.nixos.org
CONF
cp /etc/resolv.conf etc/resolv.conf

echo "== base packages"
if [ -f "$B/nixexprs.tar.xz" ]; then cp "$B/nixexprs.tar.xz" "$R/tmp/"; inroot rod +s file:///tmp/nixexprs.tar.xz; else inroot rod +s; fi
# shellcheck disable=SC2086
inroot rod +i $BASE avtty doas-uranium zoneinfo || { echo "base install failed"; exit 1; }
inroot rod -r nano 2> /dev/null || true
inroot nix-env --profile /rod/init -f /rod/nixpkgs -iA busybox
inroot nix-env --profile /rod/profile -q | wc -l

echo "== layout"
rm -f bin/sh && rmdir bin
ln -s rod/profile/bin bin
ln -s ../rod/profile/bin usr/bin
ln -s rod/profile/bin sbin
ln -s ../rod/profile/bin usr/sbin
ln -s ../rod/profile/lib/ld-linux-x86-64.so.2 lib64/ld-linux-x86-64.so.2
ln -s rod/profile/lib lib
mkdir -p etc/ssl/certs
ln -s /rod/profile/etc/ssl/certs/ca-bundle.crt etc/ssl/certs/ca-bundle.crt
rm -rf rod/nixpkgs

else
    cd "$R"
    rm -f rod/bin/firewall rod/bin/blastdoor rod/bin/geiger rod/bin/silo rod/bin/hazmat; cp "$HERE/rod" "$HERE/scram" "$HERE/uranium-install" "$HERE/uranium-chroot" "$HERE/uranium-man" "$HERE/uranium-tip" "$HERE/uranium-session" "$HERE/uranium-desktop" "$HERE/genfstab" rod/bin/
    chmod 755 rod/bin/*
    cp "$HERE"/man/*.1 rod/share/man/man1/
    cp -a "$HERE"/recipes/. rod/recipes/
    BP=/rod/profile/bin; ENVB=/rod/profile/bin/env; CERT=/rod/profile/etc/ssl/certs/ca-bundle.crt
    export BP ENVB CERT
    if [ ! -e "$R/rod/profile/bin/fetch" ]; then
        cp "$B/nixexprs.tar.xz" "$R/tmp/"
        inroot rod +s file:///tmp/nixexprs.tar.xz
        inroot rod +i fetch -r fastfetch
        rm -rf "$R/rod/nixpkgs" "$R/tmp/nixexprs.tar.xz"
    fi
fi

echo "== wrappers"
inroot sh -c 'mkdir -p /rod/wrappers && cp -L /rod/profile/bin/doas /rod/wrappers/doas && chmod 4755 /rod/wrappers/doas'

echo "== etc"
cp -a "$HERE/stage/skel/." "$R/"
printf '%s\n' $BASE avtty doas-uranium > rod/installed
cat > etc/os-release <<'CONF'
NAME="UraniumOS"
PRETTY_NAME="UraniumOS"
ID=uranium
CONF
printf 'root:x:0:0:root:/root:/rod/profile/bin/bash\nsshd:x:74:74:sshd:/var/empty:/rod/profile/bin/false\nnobody:x:65534:65534:nobody:/:/rod/profile/bin/false\n' > etc/passwd
printf 'root:x:0:\nwheel:x:10:\nnogroup:x:65534:\n' > etc/group
printf 'root::0:0:99999:7:::\n' > etc/shadow
chmod 600 etc/shadow
echo uranium > etc/hostname
printf '127.0.0.1 localhost\n::1 localhost\n' > etc/hosts
printf '/rod/profile/bin/bash\n' > etc/shells
cat > etc/rod.conf <<'CONF'
# package index channel
CHANNEL=https://channels.nixos.org/nixos-26.05/nixexprs.tar.xz
CONF
printf '# system exclusions, see scram(1)\n' > etc/scram
mkdir -p etc/scram.d
printf '# index and caches\n-/rod/nixpkgs\n-/var/cache\n-/var/tmp\n' > etc/scram.d/00-uranium.conf

echo "== clean copy"
P=$B/root-pack
if [ -d "$P" ]; then chmod -R u+w "${P:?}" && rm -rf "${P:?}"; fi
cp -a --reflink=always "$R" "$P"
rm -rf "${P:?}/rod/nixpkgs"
rm -rf "${P:?}"/tmp/*
unshare --map-auto --map-root-user --mount sh -c '
    mount --rbind /dev "$1/dev"; mount --rbind /proc "$1/proc"
    r=$1; shift
    exec chroot "$r" "$ENVB" -i HOME=/root PATH="$BP:/rod/bin" "$@"' sh "$P" nix-collect-garbage -d
unshare --map-auto --map-root-user --mount sh -c '
    mount --rbind /dev "$1/dev"; mount --rbind /proc "$1/proc"
    r=$1; shift
    exec chroot "$r" "$ENVB" -i HOME=/root PATH="$BP:/rod/bin" NIX_SSL_CERT_FILE="$CERT" "$@"' sh "$P" rod +l | wc -l

echo "== pack"
find nix -type d -exec chmod u+w {} + 2> /dev/null || true
tar --owner=0 --group=0 --numeric-owner -C "$P" -cf - . | xz -T0 -6 > "$OUT/uranium-stage-$VER.tar.xz"
ls -la "$OUT/uranium-stage-$VER.tar.xz"
(cd "$OUT" && sha256sum "uranium-stage-$VER.tar.xz" > "uranium-stage-$VER.tar.xz.sha256" && cat "uranium-stage-$VER.tar.xz.sha256")
