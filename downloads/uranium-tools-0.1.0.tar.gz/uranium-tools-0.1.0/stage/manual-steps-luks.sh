SITE=http://10.0.2.2:8765
t "uefi" test -d /sys/firmware/efi
t "partition" sh -c "wipefs -af /dev/vda && printf 'label: gpt\n,512M,U\n,,L\n' | sfdisk /dev/vda"
sleep 2
t "esp" mkfs.vfat -F32 -n URANIUMESP /dev/vda1
t "luks format" sh -c "printf pw | cryptsetup luksFormat --batch-mode --key-file=- /dev/vda2"
t "luks open" sh -c "printf pw | cryptsetup open --key-file=- /dev/vda2 uranium-root"
t "root fs" mkfs.btrfs -q -L uranium /dev/mapper/uranium-root
t "subvolumes" sh -c "mount /dev/mapper/uranium-root /mnt && btrfs subvolume create /mnt/@ && btrfs subvolume create /mnt/@home && umount /mnt"
t "mounts" sh -c "mount -o noatime,subvol=@ /dev/mapper/uranium-root /mnt && mkdir -p /mnt/home /mnt/boot /mnt/run/scram/top && mount -o noatime,subvol=@home /dev/mapper/uranium-root /mnt/home && mount /dev/vda1 /mnt/boot && mount -o subvolid=5 /dev/mapper/uranium-root /mnt/run/scram/top"
t "download stage" sh -c "cd /mnt && curl -fsSLO $SITE/downloads/uranium-stage-0.1.0.tar.xz && curl -fsSLO $SITE/downloads/uranium-stage-0.1.0.tar.xz.sha256"
t "checksum" sh -c "cd /mnt && sha256sum -c uranium-stage-0.1.0.tar.xz.sha256"
t "unpack stage" sh -c "cd /mnt && tar xpf uranium-stage-0.1.0.tar.xz --numeric-owner && rm uranium-stage-0.1.0.tar.xz uranium-stage-0.1.0.tar.xz.sha256"
t "bind mounts" sh -c "mount --rbind /dev /mnt/dev && mount -t proc proc /mnt/proc && mount --rbind /sys /mnt/sys && cp /etc/resolv.conf /mnt/etc/resolv.conf"
ch() { chroot /mnt /usr/bin/env -i HOME=/root TERM=xterm PATH=/rod/bin:/rod/profile/bin:/rod/init/bin "$@"; }
t "chroot works" sh -c "chroot /mnt /usr/bin/env -i PATH=/rod/bin:/rod/profile/bin:/rod/init/bin rod +l"
t "fstab" sh -c "chroot /mnt /usr/bin/env -i PATH=/rod/profile/bin sh -c 'printf \"LABEL=uranium /home btrfs noatime,nodev,nosuid,subvol=@home 0 0\nLABEL=uranium / btrfs noatime,subvol=@ 0 0\nLABEL=URANIUMESP /boot vfat umask=0077,nodev,nosuid,noexec 0 2\n\" > /etc/fstab'"
t "hostname" sh -c "echo luks > /mnt/etc/hostname && printf '127.0.0.1 localhost manual\n::1 localhost\n' > /mnt/etc/hosts"
t "zone" sh -c "ln -sf /rod/profile/share/zoneinfo/Europe/Helsinki /mnt/etc/localtime && echo us > /mnt/etc/keymap"
t "accounts" sh -c "chroot /mnt /usr/bin/env -i PATH=/rod/bin:/rod/profile/bin:/rod/init/bin sh -c 'echo root:rootpw | chpasswd && adduser -D -s /rod/profile/bin/bash -G wheel ann && echo ann:userpw | chpasswd'"
t "ssh on" sh -c "ln -s /etc/sv/sshd /mnt/etc/service/sshd"
t "scram apply" sh -c "chroot /mnt /usr/bin/env -i PATH=/rod/bin:/rod/profile/bin:/rod/init/bin scram apply"
t "first frame" sh -c "chroot /mnt /usr/bin/env -i PATH=/rod/bin:/rod/profile/bin:/rod/init/bin scram frame -m 'fresh install' install"
t "luks cmdline" sh -c "echo uranium.luks=UUID=\$(blkid -s UUID -o value /dev/vda2) > /mnt/etc/cmdline"
t "boot files" sh -c "chroot /mnt /usr/bin/env -i PATH=/rod/profile/bin sh -c 'mkdir -p /boot/uranium /boot/EFI/BOOT && cp -L /rod/profile/boot/vmlinuz /rod/profile/boot/initrd /boot/uranium/ && cp -L /rod/profile/share/limine/BOOTX64.EFI /boot/EFI/BOOT/'"
t "limine.conf" sh -c "U=\$(blkid -s UUID -o value /dev/vda2); printf 'timeout: 3\nserial: yes\n\n/UraniumOS\n    protocol: linux\n    path: boot():/uranium/vmlinuz\n    module_path: boot():/uranium/initrd\n    cmdline: root=LABEL=uranium rw console=tty0 console=ttyS0,115200 uranium.luks=UUID=%s\n' \$U > /mnt/boot/limine.conf"
t "limine written" test -f /mnt/boot/EFI/BOOT/BOOTX64.EFI
t "menu written" grep -q uranium.luks /mnt/boot/limine.conf
t "unmount" sh -c "umount -R /mnt/dev /mnt/proc /mnt/sys; umount -R /mnt"
t "close luks" cryptsetup close uranium-root
echo "T DONE"; poweroff
