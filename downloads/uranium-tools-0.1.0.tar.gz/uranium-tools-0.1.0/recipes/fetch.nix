{ pkgs ? import /rod/nixpkgs { } }:

pkgs.stdenv.mkDerivation {
  pname = "fetch";
  version = "2.3.0";
  src = pkgs.fetchurl {
    url = "https://github.com/areofyl/fetch/archive/1e0f767be4129976d4bece808b0110dd39ea66d7.tar.gz";
    hash = "sha256-bNvKfXm97Tbs9Dy5MN+khMF+sYaU8rNg8m+TOtSMcNk=";
  };
  patches = [ ./fetch-system-dir.patch ./fetch-value-color.patch ];
  buildPhase = ''
    cc -O2 -DFETCH_VERSION='"2.3.0"' -DFETCH_CODENAME='"Overclocked ASCII"' -DFETCH_ARCH='"x86_64"' -DFETCH_OS='"Linux"' fetch.c -o fetch -lm
  '';
  installPhase = "install -Dm755 fetch $out/bin/fetch";
  meta.license = pkgs.lib.licenses.isc;
}
