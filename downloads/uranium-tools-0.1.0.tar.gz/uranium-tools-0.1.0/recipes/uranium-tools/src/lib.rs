use std::env;
use std::fs;
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::{exit, Command, Stdio};

pub fn die(tool: &str, msg: &str) -> ! {
    eprintln!("{tool}: {msg}");
    exit(1)
}

pub fn var(name: &str, default: &str) -> String {
    env::var(name).unwrap_or_else(|_| default.to_string())
}

// environment setup
pub fn setup_env(root: &str) {
    let path = var("PATH", "");
    env::set_var("PATH", format!("{path}:{root}/profile/bin"));
    if env::var_os("NIX_SSL_CERT_FILE").is_none() {
        for c in [format!("{root}/profile/etc/ssl/certs/ca-bundle.crt"), "/etc/ssl/certs/ca-bundle.crt".to_string()] {
            if Path::new(&c).is_file() {
                env::set_var("NIX_SSL_CERT_FILE", &c);
                break;
            }
        }
    }
    if let Ok(c) = env::var("NIX_SSL_CERT_FILE") {
        env::set_var("SSL_CERT_FILE", &c);
        env::set_var("CURL_CA_BUNDLE", &c);
    }
}

pub fn need_index(tool: &str, root: &str) {
    if !Path::new(&format!("{root}/nixpkgs/default.nix")).is_file() {
        die(tool, "no package index, run: rod +s");
    }
}

// replace this process
pub fn exec(tool: &str, prog: &str, args: &[String]) -> ! {
    let e = Command::new(prog).args(args).exec();
    die(tool, &format!("cannot run {prog}: {e}"))
}

pub fn run_ok(prog: &str, args: &[&str]) -> bool {
    Command::new(prog)
        .args(args)
        .stdout(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

pub fn output(prog: &str, args: &[&str]) -> Option<String> {
    let o = Command::new(prog).args(args).stderr(Stdio::null()).output().ok()?;
    o.status.success().then(|| String::from_utf8_lossy(&o.stdout).into_owned())
}

pub fn exists(p: &str) -> bool {
    fs::symlink_metadata(p).is_ok()
}

pub fn on_path(prog: &str) -> bool {
    env::var("PATH").unwrap_or_default().split(':').any(|d| Path::new(d).join(prog).is_file())
}

// frame before a change
pub fn frame(label: &str) {
    if env::var_os("ROD_INNER").is_none() && on_path("scram") {
        let _ = Command::new("scram").args(["frame", label]).stdout(Stdio::null()).stderr(Stdio::null()).status();
    }
}

// command string
pub fn shell_cmd(args: &[String]) -> String {
    args.join(" ")
}
