#!/bin/sh
# runs inside the VM
fail=0
ok() { if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fail=1; fi; }
sub() { [ "$(stat -c %i "$1")" = 256 ]; }

mount -t proc proc /proc; mount -t sysfs sys /sys; mount -t devtmpfs dev /dev
mkfs.btrfs -q -f /dev/vda
mkdir -p /top /mnt && mount /dev/vda /top
btrfs subvolume create /top/@ > /dev/null
btrfs subvolume create /top/@home > /dev/null
cp -a /usr /bin /sbin /lib /lib64 /top/@/
mkdir -p /top/@/dev /top/@/proc /top/@/sys /top/@/tmp /top/@/etc /top/@/root /top/@/var/log /top/@/home
mkdir -p /top/@home/test/Downloads /top/@home/test/.config

live() { mount -o subvol=@ /dev/vda /mnt && mount -o subvol=@home /dev/vda /mnt/home; }
dead() { umount /mnt/home /mnt; }

export SCRAM_TOP=/top SCRAM_LIVE=/mnt HOME=/mnt/home/test SCRAM_USER_CONF=/conf SCRAM_CONF=/none
echo '-~/Downloads' > /conf
live
H=/mnt/home/test
echo f1 > $H/Downloads/f1
echo blue > $H/.config/theme
echo v1 > /mnt/usr/pkgfile

scram apply
ok "download dir became subvolume" "sub $H/Downloads"
ok "contents kept on convert" "[ -f $H/Downloads/f1 ]"
scram frame base > /dev/null
ok "frame listed" "scram roll | grep -q base"

echo red > $H/.config/theme
echo f2 > $H/Downloads/f2
echo v2 > /mnt/usr/pkgfile
D=$(scram diff base)
ok "diff shows theme" "echo '$D' | grep -q 'test/.config/theme'"
ok "diff shows package file" "echo '$D' | grep -q 'usr/pkgfile'"
ok "diff hides downloads" "! echo '$D' | grep -q Downloads"

R=$(scram restore $H/.config/theme base)
ok "restore names its source frame" "echo '$R' | grep -q -- '-base'"
ok "single file restore" "[ \"\$(cat $H/.config/theme)\" = blue ]"
ok "restore left other files" "[ \"\$(cat /mnt/usr/pkgfile)\" = v2 ]"

echo red > $H/.config/theme
dead
ok "flash refused while mounted" "mount -o subvol=@ /dev/vda /mnt && ! scram flash base 2>/dev/null; umount /mnt"
scram flash base
live
ok "flash reverts theme" "[ \"\$(cat $H/.config/theme)\" = blue ]"
ok "flash reverts package" "[ \"\$(cat /mnt/usr/pkgfile)\" = v1 ]"
ok "flash keeps new download" "[ -f $H/Downloads/f2 ] && [ -f $H/Downloads/f1 ]"
ok "downloads still subvolume" "sub $H/Downloads"
ok "pre-flash frame exists" "scram roll | grep -q pre-flash"

scram try 'echo v3 > /usr/pkgfile' > /dev/null
ok "try leaves live system" "[ \"\$(cat /mnt/usr/pkgfile)\" = v1 ]"
ok "try marks pending" "scram roll | grep -q pending"
dead
scram commit > /dev/null
ok "commit applies update" "[ \"\$(cat /top/@/usr/pkgfile)\" = v3 ]"
live

scram try 'echo bad > /usr/pkgfile; false' 2> /dev/null
ok "failed update discarded" "[ \"\$(cat /mnt/usr/pkgfile)\" = v3 ] && ! scram roll | grep -q pending"
scram try --check 'false' 'echo bad > /usr/pkgfile' 2> /dev/null
ok "failed check discarded" "! scram roll | grep -q pending && [ \"\$(cat /mnt/usr/pkgfile)\" = v3 ]"

scram try 'echo v4 > /usr/pkgfile' > /dev/null
echo racing > /mnt/usr/other
dead
ok "commit refuses after live change" "! scram commit 2> /dev/null"
scram commit --force > /dev/null
ok "force commit works" "[ \"\$(cat /top/@/usr/pkgfile)\" = v4 ] && [ ! -e /top/@/usr/other ]"
live

mkdir -p /mnt/run/scram/top && mount -o subvolid=5 /dev/vda /mnt/run/scram/top
mount -t proc proc /mnt/proc
env -u SCRAM_TOP -u SCRAM_LIVE -u SCRAM_USER_CONF -u SCRAM_CONF chroot /mnt /usr/bin/scram frame inchroot > /dev/null
ok "frame taken inside chroot" "scram roll | grep -q inchroot"
umount /mnt/proc /mnt/run/scram/top

scram frame -m "before experiment" exp > /dev/null
echo x > /mnt/usr/expfile
scram frame after-exp > /dev/null
ok "diff between two frames" "scram diff exp after-exp | grep -q usr/expfile"
ok "log shows note" "scram log | grep -q 'before experiment'"
ok "log counts changes" "scram log | grep -E -- '-after-exp +[1-9][0-9]* files changed'"
scram scratch 'echo s > /usr/scratchfile; test -f /usr/scratchfile'
ok "scratch leaves live system" "[ ! -e /mnt/usr/scratchfile ]"
ok "scratch cleans up" "! ls /top/.scram | grep -q scratch"
scram scratch 'exit 3'; rc=$?
ok "scratch returns exit code" "[ $rc = 3 ]"
mkdir -p /none.d && echo '-/mnt/srv/pg' > /none.d/pg.conf
scram apply > /dev/null
ok "package fragment applied" "sub /mnt/srv/pg"
ok "status lists exclusions" "scram status | grep -q Downloads"
echo pgdata > /mnt/srv/pg/f
ok "excluded directories are visible in a copy" "[ \"\$(scram scratch 'cat /srv/pg/f')\" = pgdata ]"

echo one > /mnt/usr/tt; scram frame t1 > /dev/null; sleep 1
echo two > /mnt/usr/tt; scram frame t2 > /dev/null; sleep 1
echo three > /mnt/usr/tt; scram frame t3 > /dev/null; sleep 1
echo four > /mnt/usr/tt; scram frame t4 > /dev/null
ok "cat from a frame" "[ \"\$(scram cat /mnt/usr/tt t2)\" = two ]"
ok "blame lists each version" "[ \$(scram blame /mnt/usr/tt | wc -l) = 5 ]"
ok "scratch -f runs in an old frame" "[ \"\$(scram scratch -f t1 'cat /usr/tt')\" = one ]"
ok "scratch -f leaves the live system" "[ \"\$(cat /mnt/usr/tt)\" = four ]"
BI=$(scram bisect t1 t4 'test "$(cat /usr/tt)" != three && test "$(cat /usr/tt)" != four')
ok "bisect finds the first bad frame" "echo '$BI' | grep -q 'first bad frame: .*-t3'"
scram send t2 > /tmp/t2.stream
ok "send writes a stream" "[ -s /tmp/t2.stream ]"
id2=$(scram roll | grep -- '-t2$')
btrfs subvolume delete /top/.scram/$id2/@ /top/.scram/$id2/@home > /dev/null; rmdir /top/.scram/$id2
ok "frame removed" "! scram roll | grep -q -- '-t2'"
scram receive < /tmp/t2.stream > /dev/null
ok "receive restores the frame" "[ \"\$(scram cat /mnt/usr/tt t2)\" = two ]"
scram try 'echo x > /usr/bootpending' > /dev/null
scram commit --boot > /dev/null
ok "commit scheduled for boot" "[ \"\$(cat /top/.scram/boot-action)\" = commit ]"
ok "status shows the scheduled action" "scram status | grep -q 'at boot'"
scram cancel
ok "cancel clears it" "[ ! -e /top/.scram/boot-action ]"
scram discard
scram flash --boot t2 > /dev/null
ok "flash scheduled for boot" "grep -q '^flash ' /top/.scram/boot-action"
scram cancel
mkdir -p /tmp/p/boot /tmp/p/share/limine /tmp/b
echo k > /tmp/p/boot/vmlinuz; echo i > /tmp/p/boot/initrd; echo e > /tmp/p/share/limine/BOOTX64.EFI
SCRAM_PROFILE=/tmp/p SCRAM_BOOT=/tmp/b scram boot 2 > /dev/null
ok "boot menu entries" "grep -q '^/UraniumOS' /tmp/b/limine.conf && grep -q 'uranium.frame=' /tmp/b/limine.conf && grep -q 'uranium.shell' /tmp/b/limine.conf"
ok "boot copies kernel and loader" "[ -f /tmp/b/uranium/vmlinuz ] && [ -f /tmp/b/uranium/initrd ] && [ -f /tmp/b/EFI/BOOT/BOOTX64.EFI ]"

SCRAM_PROFILE=/tmp/p scram frame kern1 > /dev/null
ok "a frame keeps its own kernel" "ls /top/.scram/*-kern1/boot/vmlinuz /top/.scram/*-kern1/boot/id > /dev/null"
echo k2 > /tmp/p/boot/vmlinuz
SCRAM_PROFILE=/tmp/p SCRAM_BOOT=/tmp/b scram boot 2 > /dev/null
ok "an older frame boots its own kernel" "grep -q 'uranium/k-' /tmp/b/limine.conf && [ -f /tmp/b/uranium/k-*/vmlinuz ]"
echo k > /tmp/p/boot/vmlinuz
SCRAM_PROFILE=/tmp/p SCRAM_BOOT=/tmp/b scram boot 2 > /dev/null
ok "unused kernels leave the boot partition" "! ls -d /tmp/b/uranium/k-* 2> /dev/null"
ok "status explains the frames" "scram status | grep -q 'prune:'"
scram flash --boot --root t2 > /dev/null
ok "flash can be limited to the root" "grep -q '^flash .* @\$' /top/.scram/boot-action"
scram cancel
for i in 1 2 3 4; do scram frame auto > /dev/null; sleep 1; done
scram prune 2
ok "prune keeps newest" "[ \$(scram roll | grep -c -- -auto) = 2 ]"

mkdir -p /tmp/h/pre-frame.d /tmp/h/post-frame.d
printf '#!/bin/sh\necho "pre $1" >> /tmp/h/log\n' > /tmp/h/pre-frame.d/a; printf '#!/bin/sh\necho "post $1" >> /tmp/h/log\n' > /tmp/h/post-frame.d/a
chmod +x /tmp/h/pre-frame.d/a /tmp/h/post-frame.d/a
HF=$(SCRAM_HOOKS=/tmp/h scram frame hooked)
ok "pre-frame hook ran" "grep -q '^pre hooked' /tmp/h/log"
ok "post-frame hook got the frame id" "grep -q \"^post $HF\" /tmp/h/log"
ok "doctor passes on a healthy layout" "SCRAM_BOOT=/tmp/b SCRAM_PROFILE=/tmp/p scram doctor | grep -q '^ok    subvolume @home'"
echo '@ nope/gone' >> /top/.scram/keep.list
ok "doctor fails on a missing excluded subvolume" "! SCRAM_BOOT=/tmp/b SCRAM_PROFILE=/tmp/p scram doctor | grep -q . || ! SCRAM_BOOT=/tmp/b SCRAM_PROFILE=/tmp/p scram doctor > /dev/null"
sed -i '/nope\/gone/d' /top/.scram/keep.list
for i in 1 2 3; do scram frame auto > /dev/null; sleep 1; done
old=$(scram roll | grep -- '-auto$' | sed -n 3p)
scram keep "$old" > /dev/null
ok "kept frames are marked" "scram roll | grep -q -- \"$old \\*\""
scram prune 1 > /dev/null
ok "a kept frame survives prune" "scram roll | grep -q -- \"$old\""
scram keep "$old" > /dev/null
ok "keep toggles" "! scram roll | grep -q -- \"$old \\*\""
echo "RESULT fail=$fail"
dead
