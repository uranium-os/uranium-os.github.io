#!/bin/sh
# session for the docs
mount -t proc proc /proc; mount -t sysfs sys /sys; mount -t devtmpfs dev /dev
mkfs.btrfs -q -f /dev/vda
mkdir -p /top /mnt && mount /dev/vda /top
btrfs subvolume create /top/@ > /dev/null; btrfs subvolume create /top/@home > /dev/null
cp -a /usr /bin /sbin /lib /lib64 /top/@/
mkdir -p /top/@/dev /top/@/proc /top/@/sys /top/@/tmp /top/@/etc /top/@/root /top/@/var/log /top/@/home /top/@home/alice/Downloads /top/@home/alice/.config
mount -o subvol=@ /dev/vda /mnt; mount -o subvol=@home /dev/vda /mnt/home
export SCRAM_TOP=/top SCRAM_LIVE=/mnt HOME=/mnt/home/alice SCRAM_USER_CONF=/conf SCRAM_CONF=/none
echo '-~/Downloads' > /conf
echo '=== apply'; scram apply
echo blue > $HOME/.config/theme; echo 1.0 > /mnt/usr/version
echo '=== frame'; scram frame -m "fresh install" install
echo red > $HOME/.config/theme; echo 2.0 > /mnt/usr/version; echo notes > $HOME/Downloads/notes.txt
sleep 1
scram frame -m "before kernel update" kernel > /dev/null
echo '=== roll'; scram roll
echo '=== diff install'; scram diff install
echo '=== log'; scram log
echo '=== status'; scram status
echo '=== restore'; scram restore $HOME/.config/theme install; cat $HOME/.config/theme
echo '=== try ok'; scram try 'echo 3.0 > /usr/version'
echo '=== roll pending'; scram roll | tail -2
umount /mnt/home /mnt
echo '=== commit'; scram commit
echo '=== flash'; scram flash install
mount -o subvol=@ /dev/vda /mnt; mount -o subvol=@home /dev/vda /mnt/home
echo '=== after flash'; cat $HOME/.config/theme /mnt/usr/version; ls $HOME/Downloads
echo '=== try fail'; scram try 'echo broken > /usr/version; exit 1'; echo "exit=$?"; cat /mnt/usr/version
echo '=== scratch'; scram scratch 'echo scratch > /usr/version; cat /usr/version'; cat /mnt/usr/version
echo '=== time travel'
echo uranium > /mnt/etc/hostname; scram frame hostname > /dev/null; sleep 1
echo myhost > /mnt/etc/hostname; scram frame rename > /dev/null; sleep 1
echo v3 > /mnt/usr/version; scram frame update > /dev/null
echo '--- blame'; scram blame /mnt/etc/hostname
echo '--- scratch -f'; scram scratch -f hostname 'cat /etc/hostname'
echo '--- bisect'; scram bisect hostname update 'grep -q uranium /etc/hostname'
echo '--- cat'; scram cat /mnt/etc/hostname hostname
echo '--- send'; scram send hostname | wc -c | sed 's/^/stream bytes: /'
echo '--- boot-action'; scram try 'echo x > /usr/z' > /dev/null; scram commit --boot; scram status | grep 'at boot'; scram cancel; scram discard
echo DONE
umount /mnt/home /mnt
