#!/bin/bash
# rod tests
set -u
B=${B:-$HOME/Downloads/stirner-build}
R=${1:-$B/root}
T=$B/root-egotest
[ -d "$T" ] && chmod -R u+w "${T:?}" && rm -rf "${T:?}"
cp -a --reflink=always "$R" "$T"
cp "$B/nixexprs.tar.xz" "$T/tmp/"
cp "$(dirname "$0")/../rod" "$(dirname "$0")/../scram" "$T/rod/bin/"
cat > "$T/tmp/t.sh" <<'CONF'
fail=0
ok() { if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fail=1; fi; }
rod +s file:///tmp/nixexprs.tar.xz > /dev/null
rod +i hello > /dev/null 2>&1
ok "install" "hello | grep -q 'Hello, world'"
ok "+y shows what a package needs" "rod +y hello | grep -q glibc"
ok "-y shows what needs a package" "rod -y glibc | grep -q ."
ok "+z shows the profile size" "rod +z | grep -q -E '[0-9]'"
ok "+z shows a package size" "rod +z hello | grep -q -E '[0-9]'"
rod +o /tmp/s.set > /dev/null
ok "+o writes a set" "grep -q '^pkg hello' /tmp/s.set && grep -q '^pin ' /tmp/s.set && grep -q '^recipe avtty' /tmp/s.set"
rod -r hello > /dev/null 2>&1
ok "remove" "! hello > /dev/null 2>&1"
rod +a /tmp/s.set > /dev/null 2>&1
ok "+a installs a set" "hello | grep -q 'Hello, world'"
ok "+w names the package" "rod +w /bin/ls | grep -q coreutils"
ok "+f finds a recipe" "rod +f avt | grep -q 'recipe: avtty'"
rod -i hello; ok "-i writes a hold" "grep -qx hello /rod/holds"
rod +i hello > /dev/null 2>&1; ok "+i releases the hold" "! grep -qx hello /rod/holds"
ok "+k finds an intact profile" "rod +k | grep -q intact"
ok "+q lists files" "rod +q hello | grep -q bin/hello"
ok "+x says asked for" "rod +i hello > /dev/null 2>&1; rod +x hello | grep -q asked"
ok "+x follows a dependency" "rod +x libunistring | grep -q curl"
rod -r hello > /dev/null 2>&1
rod +d hello -- true > /dev/null 2>&1
echo "RESULT fail=$fail"
CONF
unshare --map-auto --map-root-user --mount sh -c 'mount --rbind /dev "$1/dev"; mount --rbind /proc "$1/proc"; exec chroot "$1" /usr/bin/env -i HOME=/root TERM=xterm PATH=/rod/bin:/rod/profile/bin /bin/bash -lc "sh /tmp/t.sh"' sh "$T" 2>&1 | grep --line-buffered -E "^(PASS|FAIL|RESULT)|error"
