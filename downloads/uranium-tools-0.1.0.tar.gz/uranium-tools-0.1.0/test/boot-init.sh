#!/bin/bash
# initramfs boot tests
set -eu

here=$(cd "$(dirname "$0")" && pwd)
W=$(mktemp -d -p "${TMPBASE:-$HOME/Downloads/stirner-build/tmp}")
K=${KERNEL:-/usr/lib/modules/$(uname -r)/vmlinuz}

# copy tools
gather() {
    r=$1; shift
    mkdir -p "$r/usr/bin" "$r/usr/lib" "$r/proc" "$r/sys" "$r/dev" "$r/tmp" "$r/etc" "$r/home"
    ln -sfn usr/bin "$r/bin"; ln -sfn usr/bin "$r/sbin"; ln -sfn usr/lib "$r/lib"; ln -sfn usr/lib "$r/lib64"
    for b in "$@"; do
        p=$(type -P "$b") || { echo "missing $b" >&2; exit 1; }
        p=$(readlink -f "$p"); cp -L "$p" "$r/usr/bin/$b"
        ldd "$p" 2> /dev/null | awk '/=>/ && $3 ~ /^\// {print $3} /^[ \t]*\/.*ld-linux/ {print $1}' | while read -r l; do
            cp -L "$(readlink -f "$l")" "$r/usr/lib/$(basename "$l")" 2> /dev/null || true
        done
    done
    ln -sf bash "$r/usr/bin/sh"
}

TOOLS="bash sync mountpoint mount umount findfs switch_root stat date mkdir mv rm rmdir cat sleep dirname btrfs ls tr cut head echo env grep"

# real initramfs
IR=$W/initrd; gather "$IR" $TOOLS
cp "$here/../recipes/uranium-init.sh" "$IR/init"
chmod +x "$IR/init"
[ -n "${INITDEBUG:-}" ] && sed -i '2i set -x' "$IR/init"
(cd "$IR" && find . | cpio -o -H newc --quiet | gzip -1 > "$W/initrd.gz")

# small root
MR=$W/mr; gather "$MR" $TOOLS
mkdir -p "$MR/rod/init/bin" "$MR/run"
cat > "$MR/rod/init/bin/init" <<'CONF'
#!/usr/bin/bash
export PATH=/usr/bin
mount -t proc proc /proc; mount -t sysfs sys /sys; mount -t devtmpfs dev /dev
echo "INIT-UP"
echo "MARKER=$(cat /etc/marker 2> /dev/null)"
mountpoint -q /home 2> /dev/null || { mkdir -p /home; mount -t btrfs -o subvol=@home /dev/vda /home; }
echo "HOME=$(cat /home/note 2> /dev/null)"
echo "TOP=$([ -d /run/scram/top/.scram ] && echo yes || echo no)"
echo "PRE=$(ls /run/scram/top/.scram | grep -c -E 'pre-(commit|flash)')"
echo "TRIAL=$([ -f /run/scram/top/.scram/trial ] && echo yes || echo no)"
echo "FLASHLS=$(ls /run/scram/top/.scram | tr '\n' ' ')"
echo "BOOTACTION=$([ -f /run/scram/top/.scram/boot-action ] && echo yes || echo no)"
for x in $(cat /proc/cmdline); do
    case $x in
        test.confirm) rm -f /run/scram/top/.scram/trial /run/scram/top/.scram/trial-boot; echo "CONFIRMED" ;;
        test.trial) echo F1 > /run/scram/top/.scram/trial; : > /run/scram/top/.scram/trial-boot; echo "TRIALSET" ;;
        test.sched=*) echo "${x#test.sched=}" | tr : ' ' > /run/scram/top/.scram/boot-action; echo "SCHEDULED" ;;
        test.reboot) echo "REBOOTING"; sync; echo s > /proc/sysrq-trigger; sleep 1; echo b > /proc/sysrq-trigger; sleep 5 ;;
    esac
done
sync
echo o > /proc/sysrq-trigger
CONF
chmod +x "$MR/rod/init/bin/init"

# disk tree
D=$W/disk; mkdir -p "$D/.scram/F1" "$D/.scram/try"
cp -a "$MR" "$D/@"; echo base > "$D/@/etc/marker"
mkdir -p "$D/@home"; echo homebase > "$D/@home/note"
cp -a "$MR" "$D/.scram/F1/@"; echo old > "$D/.scram/F1/@/etc/marker"
mkdir -p "$D/.scram/F1/@home"; echo oldnote > "$D/.scram/F1/@home/note"
cp -a "$MR" "$D/.scram/try/@"; echo tried > "$D/.scram/try/@/etc/marker"
echo 20250101-000000-pre-update > "$D/.scram/try/state"
echo commit > "$D/.scram/boot-action"
: > "$D/.scram/keep.list"
truncate -s 2G "$W/disk.img"
mkfs.btrfs -q -f -L uranium --rootdir "$D" \
    --subvol rw:@ --subvol rw:@home --subvol ro:.scram/F1/@ --subvol ro:.scram/F1/@home --subvol rw:.scram/try/@ "$W/disk.img"

fail=0
boot() { # name append expected...
    name=$1; ap=$2; shift 2
    timeout 120 qemu-system-x86_64 -enable-kvm -m 512 -kernel "$K" -initrd "$W/initrd.gz" \
        -drive file="$W/disk.img",if=virtio,format=raw \
        -append "console=ttyS0 root=LABEL=uranium panic=-1 $ap" -display none -serial stdio -monitor none -no-reboot > "$W/$name.log" 2>&1 || true
    for e in "$@"; do
        if grep -a -q -- "$e" "$W/$name.log"; then echo "PASS $name: $e"; else echo "FAIL $name: $e"; fail=1; fi
    done
}

boot commit "test.confirm" "update committed" "MARKER=tried" "PRE=1" "BOOTACTION=no" "TOP=yes" "TRIAL=yes" "CONFIRMED"
boot frame "uranium.frame=F1" "booting frame F1" "MARKER=old" "HOME=oldnote"
boot after "test.trial" "MARKER=tried" "HOME=homebase" "TRIAL=no" "TRIALSET"
boot revert "" "was not confirmed, reverted to frame F1" "MARKER=old" "HOME=homebase" "TRIAL=no"
boot sched "test.sched=flash:F1 test.reboot" "SCHEDULED" "REBOOTING"
boot flash "" "flashed to F1" "MARKER=old" "HOME=oldnote" "PRE=2"
echo "RESULT fail=$fail"
echo "logs: $W"
exit $fail
