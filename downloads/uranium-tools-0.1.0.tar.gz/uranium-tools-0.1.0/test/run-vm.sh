#!/bin/bash
# boot test VM
set -eu
here=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d -p "${TMPBASE:-$HOME/Downloads/stirner-build/tmp}")
r=$work/root
mkdir -p $r/{usr/bin,usr/lib,proc,sys,dev,tmp,etc}
ln -s usr/bin $r/bin; ln -s usr/bin $r/sbin; ln -s usr/lib $r/lib; ln -s usr/lib $r/lib64
for b in bash cat cp mv rm rmdir mkdir touch ls stat date dirname basename readlink realpath sort head tail \
         tr sed grep awk wc mount umount mountpoint findmnt chroot sleep id uname mktemp ln btrfs mkfs.btrfs \
         rsync env true false md5sum tar cut grep tac stat sort chmod cmp df; do
    p=$(type -P $b) || { echo "missing $b" >&2; exit 1; }
    p=$(readlink -f "$p"); cp -L "$p" $r/usr/bin/$b
    ldd "$p" 2> /dev/null | awk '/=>/ && $3 ~ /^\// {print $3} /^[ \t]*\/.*ld-linux/ {print $1}' | while read -r l; do
        cp -L "$(readlink -f "$l")" "$r/usr/lib/$(basename "$l")" 2> /dev/null || true
    done
done
ln -sf bash $r/usr/bin/sh
cp "$here/../scram" "$here/../rod" $r/usr/bin/
cp "$here/${GUEST:-guest.sh}" $r/guest.sh
printf '#!/bin/sh\nexport PATH=/usr/bin\n/bin/sh /guest.sh\necho o > /proc/sysrq-trigger\n' > $r/init; chmod +x $r/init
(cd $r && find . | cpio -o -H newc --quiet | gzip -1 > $work/initrd.gz)
truncate -s 1G $work/disk.img
kernel=${KERNEL:-/usr/lib/modules/$(uname -r)/vmlinuz}
timeout 300 qemu-system-x86_64 -enable-kvm -m 768 -kernel "$kernel" -initrd $work/initrd.gz \
    -drive file=$work/disk.img,if=virtio,format=raw -append "console=ttyS0 panic=-1 rdinit=/init" \
    -display none -serial stdio -monitor none -no-reboot | tee $work/log | grep -E '^(PASS|FAIL|RESULT)|scram:' || true
echo "log: $work/log"
grep -q 'RESULT fail=0' $work/log
