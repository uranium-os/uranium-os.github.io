UraniumOS tools 0.1.0
=========================

    rod                  package manager
    scram                frames of btrfs @ and @home, reverted together
    silo, hazmat         containers and sandboxes
    blastdoor            firewall ports
    geiger               health report, used to revert a bad update
    recipes/             packages not in the index (avtty)
    man/                 manual pages
    stage/build-stage.sh builds the stage tarball
    stage/boot-test.sh   boots the stage in QEMU
    systemd/             hourly frame timer
    test/run-vm.sh       scram tests in a QEMU VM (test/guest.sh)
    logo/                ASCII logos

The handbook is on the website.

Tests
-----

    test/run-vm.sh       scram in a QEMU VM on a btrfs disk, 50 checks
    test/boot-init.sh    the initramfs: commit, frame boot and flash at boot, 16 checks
    stage/boot-test.sh   the stage on a btrfs subvolume
    stage/image-test.sh  the disk image through UEFI and limine: services, network,
                         an rod install, commit and flash at boot, a frame boot
    test/rod-chroot.sh   rod operations in a chroot of the stage

The VM tests need a kernel with btrfs and virtio built in. The image test
needs OVMF.
